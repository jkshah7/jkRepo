package MavenProj.MavenEclipseProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class App {
	public static void main(String[] args) {
		String inline = "";
		try {
			URL url = new URL(
					"https://cdn-api.co-vin.in/api/v2/appointment/sessions/calendarByDistrict?district_id=770&date=15-05-2021");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.addRequestProperty("User-Agent", "Mozilla/4.76"); 
			//System.setProperty("http.agent", "Chrome");
			conn.setRequestMethod("GET");
			conn.setRequestProperty("accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}else {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

				String output;
				
				StringBuffer response = new StringBuffer();
			    while ((output = br.readLine()) != null) {
			     	response.append(output);
			    }
			    br.close();
			    //System.out.println(response.toString() + "\n");
			   
			    JSONObject data_obj = new JSONObject(response.toString());        
	            JSONArray arr = (JSONArray) data_obj.get("centers");
	            boolean foundEmptySlot=false;
	            System.out.println("Available Centers are:" + "\n");
            	
	            for (int i = 0; i < arr.length(); i++) {
	            	JSONObject centerObj  = (JSONObject) arr.get(i);
	            	System.out.println("Center Name: " + centerObj.get("name") + " Pincode: " + centerObj.get("pincode") +"\n");
	            	JSONArray sessions = (JSONArray) centerObj.get("sessions");
                	
                	for (int j = 0; j < sessions.length(); j++) {
                		JSONObject new_obj = (JSONObject) sessions.get(j);
                		if((int)new_obj.get("min_age_limit")==18 && (int)new_obj.get("available_capacity")>0) {
                			System.out.println("==============================");
                            System.out.println("Available at Center Name: " + centerObj.get("name") + " Pincode: " + centerObj.get("pincode")
                            + " Available Capacity: " + new_obj.get("available_capacity") + "\n");
                            System.out.println("==============================");
                            foundEmptySlot = true;
                		}
                	}
	            }
	            if(!foundEmptySlot) {
	            	System.out.println("==============================");
	            	System.out.println("No Availability of Vaccine slot. Keep checking.");
	            	System.out.println("==============================");

	            }
				
			}
			
			conn.disconnect();
		} catch(Exception e){
			e.printStackTrace();
		}
	}
}
